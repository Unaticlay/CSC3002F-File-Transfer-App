# CSC3002F-File-Transfer-App

Please put the Client class and Server class seperated(under differet directory), 
the ClientHandler class needs to be with the Server class, 
along with the file "list.txt"